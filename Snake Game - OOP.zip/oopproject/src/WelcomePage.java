import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WelcomePage extends JPanel implements ActionListener {
    private JFrame frame;
    private JComboBox<String> speedSelector;
    private JButton startButton;
    private int boardWidth = 600;
    private int boardHeight = 600;
    private SnakeGame snakeGame;

    public WelcomePage(JFrame frame) {
        this.frame = frame;
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel titleLabel = new JLabel("Snake Game");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(titleLabel, gbc);

        JLabel speedLabel = new JLabel("Select Speed:");
        speedLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(speedLabel, gbc);

        speedSelector = new JComboBox<>(new String[]{"Slow", "Medium", "Fast"});
        speedSelector.setFont(new Font("Arial", Font.PLAIN, 20));
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(speedSelector, gbc);

        startButton = new JButton("Start Game");
        startButton.setFont(new Font("Arial", Font.PLAIN, 20));
        startButton.addActionListener(this);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(startButton, gbc);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String selectedSpeed = (String) speedSelector.getSelectedItem();
        int delay = 100; // Default to medium speed
        if (selectedSpeed.equals("Slow")) {
            delay = 200;
        } else if (selectedSpeed.equals("Fast")) {
            delay = 50;
        }

        snakeGame = new SnakeGame(boardWidth, boardHeight);
        snakeGame.gameLoop.setDelay(delay);
        frame.remove(this);
        frame.add(snakeGame);
        frame.pack();
        snakeGame.startGame();
    }
}