import javax.swing.*;

public class App {
    public static void main(String[] args) throws Exception {
        JFrame frame = new JFrame("Snake");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        WelcomePage welcomePage = new WelcomePage(frame);
        frame.add(welcomePage);
        frame.pack();
        frame.setVisible(true);
    }
}
